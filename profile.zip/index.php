<hr />
<a href="index.php">Back to your profile</a>
<br> |<br>
<a href="add.php">Add some new Kikz to your collection</a>
<br> |<br>
<a href="profiles.php">Check out all your Kikz</a>
<br> |<br>
<a href="search.php">Look for your Kikz</a>
<br> |<br>
<a href="delete.php">Delete some pair of Kikz from your collection</a>
